(function(){
var API_URL="";/* TEMPEL alamat Web App Google Apps Script di antara tanda kutip. Kosong = mode lokal. */
var IMG=window.ASSETS||{};
var $=function(s,r){return(r||document).querySelector(s)},$$=function(s,r){return[].slice.call((r||document).querySelectorAll(s))};
document.documentElement.classList.add('js');
$$('[data-img]').forEach(function(e){if(IMG[e.dataset.img])e.src=IMG[e.dataset.img]});
/* menu */
var menu=$('#nav-menu');
$('#nav-toggle').onclick=function(){menu.classList.add('show')};
$('#nav-close').onclick=function(){menu.classList.remove('show')};
$$('.nav__link').forEach(function(a){a.onclick=function(){menu.classList.remove('show')}});
/* theme */
var root=document.documentElement,tb=$('#theme-button');
function setTheme(t){root.dataset.theme=t;tb.firstChild.nextSibling?0:0;tb.innerHTML='<svg class="i"><use href="#'+(t==='dark'?'sun':'moon')+'"/></svg>'}
var saved=null;try{saved=localStorage.getItem('theme')}catch(e){}
setTheme(saved||'light');
tb.onclick=function(){var t=root.dataset.theme==='dark'?'light':'dark';setTheme(t);try{localStorage.setItem('theme',t)}catch(e){}};
/* sliders */
$$('.slider').forEach(function(s){
 var tr=$('.slider__track',s),n=$$('.slide',s).length,i=0,tm,x0=null;
 function go(k){i=(k+n)%n;tr.style.transform='translateX(-'+i*100+'%)'}
 function play(){var d=+s.dataset.auto;if(d&&!matchMedia('(prefers-reduced-motion:reduce)').matches){clearInterval(tm);tm=setInterval(function(){go(i+1)},d)}}
 $('.prev',s).onclick=function(){go(i-1);play()};
 $('.next',s).onclick=function(){go(i+1);play()};
 s.onmouseenter=function(){clearInterval(tm)};s.onmouseleave=play;
 s.addEventListener('touchstart',function(e){x0=e.touches[0].clientX},{passive:true});
 s.addEventListener('touchend',function(e){if(x0===null)return;var d=e.changedTouches[0].clientX-x0;if(Math.abs(d)>40){go(i+(d<0?1:-1));play()}x0=null});
 play();
});
/* scroll: header, scrollup, active link */
var hd=$('#header'),up=$('#scroll-up'),secs=$$('main section[id]'),links=$$('.nav__link');
function onScroll(){
 var y=window.scrollY;hd.classList.toggle('scrolled',y>40);up.classList.toggle('show',y>350);
 var cur=secs[0].id;secs.forEach(function(s){if(y+120>=s.offsetTop)cur=s.id});
 links.forEach(function(a){a.classList.toggle('active-link',a.getAttribute('href')==='#'+cur)});
}
addEventListener('scroll',onScroll,{passive:true});onScroll();
/* reveal */
var rv=$$('.rv');
if('IntersectionObserver' in window){
 var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}})},{threshold:.12});
 rv.forEach(function(e){io.observe(e)});
}else rv.forEach(function(e){e.classList.add('in')});

var CENTRAL=!!API_URL;
var IND=[["Bersih","kegiatan","beach"],["Asri","kegiatan","isl"],["Rindang","kegiatan","alp"],["Indah","kegiatan","lake"],["Sehat","kegiatan","bg"],["Aman","kegiatan","alp"],["Nyaman","kegiatan","isl"]],KEY="bsipakainge-monev",mem=[];
function lload(){try{return JSON.parse(localStorage.getItem(KEY))||[]}catch(e){return mem}}
function lsave(d){mem=d;try{localStorage.setItem(KEY,JSON.stringify(d))}catch(e){}}
var DATA=CENTRAL?[]:lload();
function load(){return DATA}
function save(d){DATA=d;if(!CENTRAL)lsave(d)}
function setStat(t){$("#stat").textContent=t}
function api(b){return fetch(API_URL,{method:"POST",headers:{"Content-Type":"text/plain;charset=utf-8"},body:JSON.stringify(b)}).then(function(r){return r.json()})}
function norm(r){return{id:String(r.id),tgl:String(r.tgl).slice(0,10),nama:String(r.nama),wil:String(r.wil),sk:String(r.sk),ind:+r.ind,tg:parseFloat(r.tg),rl:parseFloat(r.rl),cat:String(r.cat||"")}}
function refresh(){if(!CENTRAL)return Promise.resolve();setStat("Memuat data dari Google Sheets...");
 return fetch(API_URL+"?action=list").then(function(r){return r.json()}).then(function(j){if(!j.ok)throw 0;
  DATA=j.data.map(norm).filter(function(x){return x.ind>=0&&x.ind<IND.length&&x.tg>0&&!isNaN(x.rl)});render();
  setStat("Terhubung ke Google Sheets. Diperbarui "+new Date().toLocaleTimeString("id-ID",{hour:"2-digit",minute:"2-digit"})+".")}).catch(function(){setStat("Gagal memuat data dari Google Sheets. Periksa koneksi atau alamat Apps Script.")})}
function esc(s){return String(s).replace(/[&<>"']/g,function(c){return{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]})}
function pct(r,t){return t>0?Math.round(r/t*100):0}
function cls(p){return p>=80?"":p>=50?" m":" l"}
var sel=$("#ind");IND.forEach(function(x,i){sel.add(new Option(x[0],i))});
function unit(){var u="("+IND[sel.value][1]+")";$("#u1").textContent=u;$("#u2").textContent=u}
sel.onchange=unit;unit();
function render(){
 var d=load(),R=0,T=0,w={},bm=0,now=new Date().toISOString().slice(0,7);
 d.forEach(function(x){R+=x.rl;T+=x.tg;w[x.wil.toLowerCase()]=1;if(x.tgl.slice(0,7)===now)bm++});
 $("#s1").textContent=d.length;$("#s2").textContent=pct(R,T)+"%";$("#s3").textContent=Object.keys(w).length;$("#s4").textContent=bm;$("#sb").style.width=Math.min(pct(R,T),100)+"%";
 $("#cards").innerHTML=IND.map(function(x,i){var r=0,t=0;d.forEach(function(y){if(+y.ind===i){r+=y.rl;t+=y.tg}});var p=pct(r,t);
  return '<article class="destination__card"><img src="'+(IMG[x[2]]||'')+'" alt="" class="destination__img"><div class="destination__data"><h3 class="destination__subtitle">'+r+' / '+t+' '+x[1]+'</h3><h2 class="destination__title">'+esc(x[0])+'</h2><p class="destination__country"><b>'+p+'%</b>&nbsp;capaian</p><div class="trk"><i style="width:'+Math.min(p,100)+'%"></i></div></div></article>'}).join("");
 $("#tb").innerHTML=d.slice().sort(function(a,b){return b.tgl.localeCompare(a.tgl)}).map(function(x){var p=pct(x.rl,x.tg);
  return '<tr><td>'+esc(x.tgl)+'</td><td><b>'+esc(x.nama)+'</b><br><small>'+esc(x.sk)+(x.cat?' &middot; '+esc(x.cat):'')+'</small></td><td>'+esc(x.wil)+'</td><td>'+esc(IND[x.ind][0])+'</td><td>'+x.rl+' / '+x.tg+' '+IND[x.ind][1]+'</td><td><span class="pill'+cls(p)+'">'+p+'%</span></td><td><button class="button line" data-id="'+x.id+'">Hapus</button></td></tr>'}).join("");
 $("#em").style.display=d.length?"none":"block";
}
function msg(t,ok){var m=$("#msg");m.textContent=t;m.style.color=ok?"#1f8a5b":"#d64545"}
$("#f").addEventListener("submit",function(e){
 e.preventDefault();
 var v={nama:$("#nama").value.trim(),tgl:$("#tgl").value,wil:$("#wil").value.trim(),sk:$("#sk").value.trim(),ind:+sel.value,tg:parseFloat($("#tg").value),rl:parseFloat($("#rl").value),cat:$("#cat").value.trim(),id:Date.now()};
 if(!v.nama||!v.tgl||!v.wil||!v.sk||!(v.tg>0)||isNaN(v.rl)||v.rl<0){msg("Lengkapi semua kolom wajib. Target harus lebih dari 0.",false);return}
 var fm=this;
 if(CENTRAL){msg("Menyimpan ke Google Sheets...",true);api({action:"add",row:v}).then(function(r){if(!r.ok)throw 0;fm.reset();unit();return refresh()}).then(function(){msg("Laporan tersimpan di Google Sheets.",true)}).catch(function(){msg("Gagal menyimpan. Periksa koneksi atau alamat Apps Script.",false)});return}
 var d=load();d.push(v);save(d);fm.reset();unit();render();msg("Laporan tersimpan. Capaian sudah diperbarui.",true);
});
$("#tb").addEventListener("click",function(e){var b=e.target.closest("[data-id]");if(!b||!confirm("Hapus laporan ini?"))return;if(CENTRAL){var pin=prompt("Masukkan PIN admin untuk menghapus laporan:");if(!pin)return;api({action:"delete",id:b.dataset.id,pin:pin}).then(function(r){if(!r.ok)throw 0;return refresh()}).catch(function(){alert("Gagal menghapus. PIN salah atau koneksi bermasalah.")});return}
 save(load().filter(function(x){return String(x.id)!==b.dataset.id}));render()});
$("#clr").onclick=function(){if(load().length&&confirm("Hapus semua laporan?")){save([]);render()}};
$("#demo").onclick=function(){var t=new Date().toISOString().slice(0,10),d=load(),n=Date.now();
 [["Kerja bakti dan pemilahan sampah","Kota Makassar","MAN 3 Kota Makassar",0,10,8],["Penataan taman madrasah","Kab. Gowa","MTsN 1 Gowa",1,5,4],["Tanam pohon di halaman masjid","Kab. Maros","KUA Maros Baru",2,20,12],["Pengecatan dan penghiasan lingkungan","Kab. Bone","KUA Tanete Riattang",3,6,3],["Senam dan sosialisasi hidup sehat","Kab. Wajo","Kemenag Wajo",4,8,8],["Piket dan patroli lingkungan","Kab. Soppeng","MAN Soppeng",5,10,7],["Penataan ruang ibadah dan kelas","Kab. Takalar","MIN 1 Takalar",6,6,5]].forEach(function(x,i){d.push({nama:x[0],wil:x[1],sk:x[2],ind:x[3],tg:x[4],rl:x[5],tgl:t,cat:"Contoh data",id:n+i})});
 save(d);render()};
$("#csv").onclick=function(){var d=load();if(!d.length){alert("Belum ada data untuk diunduh.");return}
 function q(s){s=String(s);if(/^[=+\-@]/.test(s))s="'"+s;return '"'+s.replace(/"/g,'""')+'"'}
 var rows=[["Tanggal","Kegiatan","Wilayah","Satuan Kerja","Indikator","Target","Realisasi","Capaian (%)","Catatan"].map(q).join(",")].concat(d.map(function(x){return [x.tgl,x.nama,x.wil,x.sk,IND[x.ind][0],x.tg,x.rl,pct(x.rl,x.tg),x.cat].map(q).join(",")}));
 var a=document.createElement("a");a.href=URL.createObjectURL(new Blob(["\ufeff"+rows.join("\r\n")],{type:"text/csv;charset=utf-8"}));a.download="b-sipakainge-monev.csv";document.body.appendChild(a);a.click();a.remove()};
if(CENTRAL){$("#demo").style.display="none";$("#clr").style.display="none";$("#rf").style.display="";$("#rf").onclick=refresh;setInterval(function(){if(!document.hidden)refresh()},60000);refresh()}
else setStat("Mode lokal: data hanya tersimpan di perangkat ini.");
render();
})();
